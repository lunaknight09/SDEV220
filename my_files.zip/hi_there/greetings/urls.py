from django.urls import path
from . import views

urlpatterns = [
    path("general-kenobi", views.generalKenobi)
    ]