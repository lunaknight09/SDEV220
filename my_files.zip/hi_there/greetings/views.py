from django.shortcuts import render

# Create your views here.


def generalKenobi(request):
    data = {"title": "hello", "message": "why hello there"}
    return render(request, "sayhi.html", data)

